package Game3;

import javafx.scene.layout.Pane;
import javafx.scene.shape.Shape;


/**
 *
 * @author PC
 */
public class Map extends Pane{
 
Shape [] shape ;
    
    public Map(){
        
    }
}